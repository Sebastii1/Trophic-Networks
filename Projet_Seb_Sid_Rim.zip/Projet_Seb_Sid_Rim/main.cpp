#include "grman/grman.h"
#include <iostream>
#include <fstream>
#include <stack>

#include "graph.h"

/**<    Le code initial est celui donn� par Monsieur Fercoq. Les fonctions ajout�es ou modifi�es sont comment�es par nos soins
        Pour la partie Allegro: il est possible que les fonctions utilis�es soient en C (et pas C++)
        Les sources annexes sont donn�es dans le PPT joint au rendu du code
*/


using namespace std;


    /** \brief
     *
     * \param choix=0 int
     * \return int
     *
     */
    int menu(int choix=0)   /**< Menu initial (choix entre cr�er un graphe et travailler avec un graphe d�j� construit) */
{
    BITMAP* paint_menu;
    bool selectionne=false;

           paint_menu=load_bitmap("menu.bmp", NULL);      //on utilise des images de menus (cr��s via Paint)
            selectionne=false;
            blit(paint_menu,screen,0,0,0,0,SCREEN_W,SCREEN_H);
            while(!selectionne)
            {
                    if(mouse_b&1 && 84<mouse_y && mouse_y<206 && 38<mouse_x && mouse_x<797)     //le choix est d�termin� en fonction de l'endroit o� clique l'utilisateur
                    {
                        choix=1;
                        selectionne=true;
                    }
                    else if(mouse_b&1 && 300<mouse_y && mouse_y<416 && 38<mouse_x && mouse_x<797)
                    {
                        choix=2;
                        selectionne=true;
                    }
            }
        return choix;
}


/** \brief
 *
 * \param choix=0 int
 * \return int
 *
 */
int menu_graphe(int choix=0)    /**< Menu du choix du graphe sur lequel on travaille */
{
    BITMAP* paint_menu;
            paint_menu=load_bitmap("graphes.bmp", NULL);
            bool selectionne=false;
            while(!selectionne)
            {
                blit(paint_menu,screen,0,0,0,0,SCREEN_W,SCREEN_H);
                if(mouse_b&1 && mouse_x<50 && mouse_y<50)
                    choix=menu(0);
                if(mouse_b&1 && 38<mouse_y && mouse_y<200 && 54<mouse_x && mouse_x<790)
                {
                    choix=1;
                    selectionne=true;
                }
                else if(mouse_b&1 && 220<mouse_y && mouse_y<343 && 54<mouse_x && mouse_x<790)
                {
                    choix=2;
                    selectionne=true;
                }
                else if(mouse_b&1 && 400<mouse_y && mouse_y <520 && 54<mouse_x && mouse_x<790)
                {
                    choix=3;
                    selectionne=true;
                }
            }
            return choix;
}

void creer_graphe(int choix, Graph g, BITMAP* buffer)
{
    BITMAP* barre;
    barre=load_bitmap("barre.bmp", NULL);
        blit(barre,buffer, 0,0,0,0, SCREEN_W, SCREEN_H);
        blit(buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);

        if(mouse_b&1 && mouse_x<112 && mouse_y<35)
            choix=menu(0);
            ///on quitte le module de creation de graphe (retour au menu de base)

        if(mouse_b&1 && mouse_x>86 && mouse_x<166 && mouse_y<35)

            //  sauvegarde_graphe(g);
            //appel de la fonction permettant de sauvegarder le graphe actuel

        if(mouse_b&1 && mouse_x>166 && mouse_x<254 && mouse_y<35)

            //appel de la fonction permettant de charger les graphes sauvegard�s

        if(mouse_b&1 && mouse_x>255 && mouse_x<337 && mouse_y<35)

            //appel de la fonction permettant d'ajouter sommet, aretes etc

        if(mouse_b&1 && mouse_x>337 && mouse_x<459 && mouse_y<35)
            g.test_remove_edge(1);
            //appel de la fonction permettant de supprimer sommet, aretes etc
}

void sauvegarde_graphe(Graph g)
{
    g.m_ordre=7;
    vector <Edge> copie;
    ofstream fichier("base_donnee.txt", ios::out);
    for(int i=0; i<g.m_ordre; i++)
    {
        cout << g.m_edges[i].m_from <<endl;
        copie.emplace_back(g.m_edges[i]);
        fichier << copie[i].m_from;
        fichier << "  ";
        fichier<<copie[i].m_to;
        fichier <<endl;
        //copie.pop();
    }
}

/** \brief
 *
 * \param nomfichier string
 * \return bool
 *
 */
bool connexite(string nomfichier)
{
    ifstream fichier(nomfichier, ios::in);
    int ordre;
    fichier >> ordre;
    int som=0;
    int verif=0;
    int comp=0;
    vector<bool> connexe;
    stack<int> pile;

    pile.push(som);

    for(int i=0; i<ordre; i++)
        connexe.push_back(false);


    int matrice_adj[ordre][ordre];
    for(int i=0; i<ordre; i++)
    {
        for(int j=0; j<ordre; j++)
            fichier >> matrice_adj[i][j];
    }

    while(!pile.empty())
   {
        som=pile.top();

        pile.pop();
        connexe[som]=true;
        for(int i=0; i<ordre; i++)
       {
            if(matrice_adj[som][i]==1 && connexe[i]==false)
            {
                    pile.push(i);
                    connexe[i]=true;
            }
       }
   }
    for(int i=0; i<connexe.size(); i++)
   {
       if(connexe[i]==false)
            verif++;
   }
   if(verif!=0)
        return false;
    else
        return true;
}

void k_connexite(string nomfichier, string nouveaufichier)
{
    int som=0;
    int verif=0;
    int comp=0;
    vector<bool> connexe;
    stack<int> pile;

    pile.push(som);

    vector <int> sommets;
    sommets.push_back(0);   // pour �viter de vider un vecteur vide � la premi�re rentr�e dans la boucle
    bool k_connexe=true;
    ifstream fichier(nomfichier, ios::in);
    int ordre;
    fichier >> ordre;
    for(int i=0; i<ordre; i++)
        connexe.push_back(false);

    int matrice_modif[ordre][ordre];
    int nouv_matrice[ordre][ordre];
    int cpt=0;

    for(int i=0; i<ordre; i++)
    {
        for(int j=0; j<ordre; j++)
            fichier >> matrice_modif[i][j];

    }

    while(k_connexe)
    {
        for(int vider=0; vider<sommets.size(); vider++) //on vide le sommet pour avoir les sommets � supprimer
            sommets.pop_back();

        for(int i=0; i<ordre; i++)
        {
            for(int j=0; j<ordre; j++)
            {
                if(i==cpt || j==cpt)
                    nouv_matrice[i][j]=0;
                else
                    nouv_matrice[i][j]=matrice_modif[i][j];
            }

        }
        sommets.push_back(cpt);

    while(!pile.empty())
   {
        som=pile.top();

        pile.pop();
        connexe[som]=true;
        for(int i=cpt; i<ordre; i++)
       {
            if(nouv_matrice[som][i]==1 && connexe[i]==false)
            {
                    pile.push(i);
                    connexe[i]=true;
            }
       }
   }
    for(int i=0; i<connexe.size(); i++)
   {
       if(i!=cpt && connexe[i]==false)
            verif++;
   }
   if(verif!=0)
        k_connexe= false;

        cpt++;
    }
    cout << "Le graphe est " <<sommets.size() <<"-connexe" <<endl;
    cout << "Il faut retirer le(s) sommet(s) ";
    for(int compte=0; compte<sommets.size(); compte++)
        cout << sommets[compte] << " et ";

    cout <<endl;
}

/** \brief
 *
 * \param g Graph
 * \param numero_graphe int
 * \param nomfichier string
 * \param nouveau_fichier string
 * \return void
 *
 */
void clique_bouton(Graph g, int numero_graphe, string nomfichier, string nouveau_fichier)
{
    if(mouse_b&1 && mouse_x>86 && mouse_x<165 && mouse_y<50)
        cout << "A";
        //appel de la fonction permettant de sauver le graphe
    if(mouse_b&1 && mouse_x>165 && mouse_x<255 && mouse_y<50)
        cout << "B";
        //appel de la fonction permettant de charger un graphe
    if(mouse_b&1 && mouse_x>255 && mouse_x<338 && mouse_y<50)
        cout << "C";
        //appel de la fonction permettant d'ajouter un sommet
    if(mouse_b&1 && mouse_x>337 && mouse_x<459 && mouse_y<50)
    {
        int arete_suppr;
        cout << "Quelle adresse souhaitez vous supprimer?";
        cin >> arete_suppr;
         g.test_remove_edge(arete_suppr);
    }

        //appel de la fonction permettant de supprimer un sommet
    if(mouse_b&1 && mouse_x>459 && mouse_x<576 && mouse_y<50)
    {
        bool fort_connexe;
        fort_connexe=connexite(nomfichier); /**< appel de la fonction permettant de verifier si un graphe est fortement connexe ou non */
        if(fort_connexe)
            cout << "Le graphe est fortement connexe" <<endl;
        else
            cout << "Le graphe n'est pas fortement connexe" << endl;
    }
    if(mouse_b&1 && mouse_x>576 && mouse_x<711 && mouse_y<50)
        k_connexite(nouveau_fichier, "nouveau_fichier.txt");

}

int main()
{
    int choix_graphe=0;
    int choix=0;

    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    /**< Chargement des images et des BITMAP */
    BITMAP* buffer;
    buffer=create_bitmap(SCREEN_W, SCREEN_H);
    BITMAP* barre;
    barre=load_bitmap("barre.bmp", NULL);

    /// Le nom du r�pertoire o� se trouvent les images � charger
    grman::set_pictures_path("pics");

    /// Un exemple de graphe
    Graph g;
    //g.make_example();
    install_keyboard();
    sauvegarde_graphe(g);

    /// Vous gardez la main sur la "boucle de jeu"
    /// ( contrairement � des frameworks plus avanc�s )
    while ( !key[KEY_ESC] )
    {
        clear(buffer);
        choix=menu(choix);
        if(choix==1)
        {
            choix_graphe=menu_graphe(choix);

            if(choix_graphe==1)
            {
                while(!(mouse_b&1 && mouse_x<85 && mouse_y<50))
                {
                    std::cerr<<std::endl;
                    g.lecture();
                    ///g.update();
                    //g.create_edge();
                    //g.Sauvegarder(std:: string flux);
                    g.delete_edge();
                    ///grman::mettre_a_jour();
                    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
                    g.update();
                    /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                    grman::mettre_a_jour();
                    clique_bouton(g, 1, "matrice1.txt", "matrice_adj1.txt");

                }
                choix_graphe=menu_graphe(choix);

            }
                //afficher graphe 1
            if(choix_graphe==2)
            {
                while(!(mouse_b&1&&mouse_x<50&&mouse_y<50))
                {
                    //cout << "2";
                    ///clique_bouton(2, "matrice2.txt");
                //afficher graphe 2
                }
            }
            if(choix_graphe==3)
            {
                while(!(mouse_b&1&&mouse_x<50&&mouse_y<50))
                {
                    //cout << "3";
                    g.make_graph();
                    g.update();
                    grman::mettre_a_jour();
                    ///clique_bouton(3, "matrice3.txt");
                    //afficher graphe 3
                }
            }
        }
        if(choix==2)
            creer_graphe(choix, g, buffer);
    }

    grman::fermer_allegro();



    return 0;
}
END_OF_MAIN();


