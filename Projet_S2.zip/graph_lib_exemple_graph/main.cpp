#include "grman/grman.h"
#include <iostream>
#include <fstream>
#include <stack>

#include "graph.h"

/**<    Le code initial est celui donn� par Monsieur Fercoq. Les fonctions ajout�es ou modifi�es sont comment�es par nos soins
        Pour la partie Allegro: il est possible que les fonctions utilis�es soient en C (et pas C++)
        Les sources annexes sont donn�es dans le PPT joint au rendu du code
*/


using namespace std;


    /** \brief
     *
     * \param choix=0 int
     * \return int
     *
     */
    int menu(int choix=0)   /**< Menu initial (choix entre cr�er un graphe et travailler avec un graphe d�j� construit) */
{
    BITMAP* paint_menu;
    bool selectionne=false;

           paint_menu=load_bitmap("menu.bmp", NULL);      //on utilise des images de menus (cr��s via Paint)
            selectionne=false;
            blit(paint_menu,screen,0,0,0,0,SCREEN_W,SCREEN_H);
            while(!selectionne && !key[KEY_ESC])
            {
                    if(mouse_b&2 && 75<mouse_y && mouse_y<190 && 60<mouse_x && mouse_x<810)     //le choix est d�termin� en fonction de l'endroit o� clique l'utilisateur
                    {
                        choix=1;
                        selectionne=true;
                    }
                    if(mouse_b&2 && 255<mouse_y && mouse_y<355 && 115<mouse_x && mouse_x<810)
                    {
                        choix=2;
                        selectionne=true;
                    }
                    if(mouse_b&2 && 430<mouse_y && mouse_y<530 && 115<mouse_x && mouse_x<810)
                    {
                        choix=3;
                        selectionne=true;
                    }
            }
        return choix;
}


/** \brief
 *
 * \param choix=0 int
 * \return int
 *
 */
int menu_graphe(int choix=0)    /**< Menu du choix du graphe sur lequel on travaille */
{
    BITMAP* paint_menu;
            paint_menu=load_bitmap("graphes.bmp", NULL);       //encore une fois, on utilise un menu cr�� via paint...
            bool selectionne=false;
            while(!selectionne && !key[KEY_ESC])
            {
                blit(paint_menu,screen,0,0,0,0,SCREEN_W,SCREEN_H);
                if(mouse_b&1 && mouse_x<50 && mouse_y<50)
                    choix=menu(0);
                if(mouse_b&1 && 38<mouse_y && mouse_y<200 && 54<mouse_x && mouse_x<790)     //et on d�termine l'action � effectuer en fonction de la position de la sourix
                {
                    choix=1;
                    selectionne=true;
                }
                else if(mouse_b&1 && 220<mouse_y && mouse_y<343 && 54<mouse_x && mouse_x<790)
                {
                    choix=2;
                    selectionne=true;
                }
                else if(mouse_b&1 && 400<mouse_y && mouse_y <520 && 54<mouse_x && mouse_x<790)
                {
                    choix=3;
                    selectionne=true;
                }
            }
            return choix;
}

/** \brief
 *
 * \param nomfichier string
 * \return bool
 *
 */
bool connexite(string nomfichier)            /**< Fonction permettant de d�terminer si un graphe est connexe */
{
    ifstream fichier(nomfichier, ios::in);
    int ordre;
    fichier >> ordre;       //on lit les informations du fichier
    int som=0;          //sommet sur lequel on se pace
    int verif=0;        //variable utilis�e pour v�rifier si le graphe est (fortement) connexe (voir plus bas)
    int comp=0;
    vector<bool> connexe;
    stack<int> pile;        //file d'attente qui permettra d'empiler les sommets

    pile.push(som);         //on initialise la pile...

    for(int i=0; i<ordre; i++)
        connexe.push_back(false);       //et le vecteur de bool�en


    int matrice_adj[ordre][ordre];      //on d�clare la matrice d'adjacence
    for(int i=0; i<ordre; i++)
    {
        for(int j=0; j<ordre; j++)
            fichier >> matrice_adj[i][j];   //on rempli une matrice avec les infos du fichier
    }

    /**< L'algorithme permettant de savoir si un graphe est (fortement) connexe
            semblable � un BFS  */

    while(!pile.empty())        //tant que la file d'attente n'est pas vide
   {
        som=pile.top();         //on s'int�resse au sommmet ce situant au sommet de la pile

        pile.pop();             //on d�file la pile
        connexe[som]=true;          //le sommet regard� est connexe
        for(int i=0; i<ordre; i++)
       {
            if(matrice_adj[som][i]==1 && connexe[i]==false)     //si le sommet regard� est adjacent � l'autre sommet (d'indice i)
            {
                    pile.push(i);       //on met le sommet en question dans la pile
                    connexe[i]=true;        //et on le marque
            }
       }
   }
    for(int i=0; i<connexe.size(); i++)     //boucle permettant de savoir si le graphe est (fortement) connexe en fonction du vecteur de bool�en
   {                                   //le graphe est (fortement) connexe si le vecteur de bool�ens n'est compos� que de "vrais"
       if(connexe[i]==false)
            verif++;
   }
   if(verif!=0)
        return false;
    else
        return true;
}


void k_connexite(string nomfichier)     //fonction permettant d'�tudier la k-connexti� d'un graphe
                                            //non fonctionnelle pour le moment
{
    ofstream nouveau_fichier("nouveau_fichier.txt", ios::out);
    bool connexe=true;
    int ordre;
    int cpt=0;
    int k=0;
    ifstream fichier(nomfichier, ios::in);
    fichier >> ordre;
    int matrice_adj[ordre][ordre];
    for(int i=0; i<ordre; i++)
    {
        for(int j=0; j<ordre; j++)
            fichier >> matrice_adj[i][j];
    }
    while(connexe)
    {
        for(int compteur=0; compteur<ordre; compteur++)
        {
             for(int i=0; i<ordre; i++)
            {
                for(int j=0; j<ordre; j++)
                {
                    if(i==cpt || j==cpt)
                    matrice_adj[i][j]=0;
                }
            }
            cpt++;
            for(int i=0; i<ordre; i++)
            {
                for(int j=0; j<ordre; j++)
                    nouveau_fichier << matrice_adj[i][j] << " ";
                nouveau_fichier << endl;
            }

            connexe=connexite("nouveau_fichier.txt");
            k++;
        }


    }
    cout << "Le graphe est " <<k <<"-connexe" <<endl;


}

/** \brief
 *
 * \param g Graph
 * \param numero_graphe int
 * \param nomfichier string
 * \param nouveau_fichier string
 * \return void
 *
 */
void clique_bouton(Graph g, int numero_graphe, string nomgraphe, string nomfichier, string nouveau_fichier, bool charge)  /**< Permet de conna�tre l'action que veut effectuer l'utilisateur avec son graphe */
{
    if(mouse_b&1 && mouse_x>86 && mouse_x<165 && mouse_y<50)    /**< sauver graphe */ //comme pr�c�demment, on regarde la position de la souris
    {
        if(charge==false)
            cout << "Vous n'avez pas selectionne le bon menu. Vous ne pouvez pas sauvez le graphe ici" <<endl;
        if(charge==true)
            g.Sauvegarder(nomgraphe); //on sauve le graphe
    }

    if(mouse_b&1 && mouse_x>165 && mouse_x<255 && mouse_y<50)   /**< charger graphe */
    {
        if(charge==false)
            cout << "Vous n'avez pas selectionne le bon menu. Vous ne pouvez pas charger de graphe ici" <<endl;
        if(charge==true)
            cout << "B";    //on charge un graphe
    }

    if(mouse_b&1 && mouse_x>255 && mouse_x<338 && mouse_y<50)   /**< ajouter sommet */
    {
        if(charge==false)
            cout << "Vous n'avez pas selectionne le bon menu. Vous ne pouvez pas modifier le graphe ici"<<endl;
        if(charge==true)
        {
            g.add_sommet();
            g.update();
            grman::mettre_a_jour();
        }  // cout << "C"; //on ajoute un sommet
    }

    if(mouse_b&1 && mouse_x>337 && mouse_x<459 && mouse_y<50)   /**< supprimer sommet */
    {
        if(charge==false)
            cout << "Vous n'avez pas selectionne le bon menu. Vous ne pouvez pas modifier le graphe ici" <<endl;
        if(charge==true)
            g.delete_som();
         //   cout <<"D"; // on supprime un sommet
    }

    if(mouse_b&1 && mouse_x>459 && mouse_x<576 && mouse_y<50)   /**< �tudier connexit� */
    {
        if(charge==false)
        {
            bool fort_connexe;
        fort_connexe=connexite(nomfichier); /**< appel de la fonction permettant de verifier si un graphe est fortement connexe ou non */
        if(fort_connexe)
            cout << "Le graphe est fortement connexe" <<endl;
        else
            cout << "Le graphe n'est pas fortement connexe" << endl;
        }
        if(charge==true)
            cout << "Vous n'avez pas selectionne le bon menu. Vous ne pouvez pas etudier le graphe ici." <<endl;
    }
    if(mouse_b&1 && mouse_x>576 && mouse_x<711 && mouse_y<50)   /**< �tudier k-connexit� */
    {
        if(charge==false)
            k_connexite("matrice_adj.txt");
        if(charge==true)
            cout << "Vous n'avez pas selectionne le bon menu. Vous ne pouvez pas etudier le graphe ici." <<endl;
    }

}

int main()
{
    int choix_graphe=0;     //permettent de r�cup�rer le choix de l'utilisateur
    int choix=0;

    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    /**< Chargement des images et des BITMAP */
    BITMAP* buffer;                             //buffer pour �viter les clignotements
    buffer=create_bitmap(SCREEN_W, SCREEN_H);


    /// Le nom du r�pertoire o� se trouvent les images � charger
    grman::set_pictures_path("pics");


    Graph g1, g2, g3;
    cerr<<endl;
    g1.lecture("graphe1.txt");    //on lit les graphes � charger
    g2.lecture("graphe2.txt");
    g3.lecture("graphe3.txt");

    /// Vous gardez la main sur la "boucle de jeu"
    /// ( contrairement � des frameworks plus avanc�s )
    while ( !key[KEY_ESC] )
    {
        clear(buffer);
        choix=menu(choix);
        if(choix==1)        //On effectue les actions en fonction du choix de l'utilisateur
        {
            choix_graphe=menu_graphe(choix);

            if(choix_graphe==1)
            {
                while(!(mouse_b&1 && mouse_x<85 && mouse_y<50) && !key[KEY_ESC])
                {

                    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets

                    g1.update();

                    /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                    grman::mettre_a_jour();
                    clique_bouton(g1, 1, "graphe1.txt", "matrice1.txt", "matrice_adj1.txt", false);
                }
                choix_graphe=menu_graphe(choix);

            }
                //afficher graphe 1
            if(choix_graphe==2)
            {
                while(!(mouse_b&1 && mouse_x<85 && mouse_y<50) && !key[KEY_ESC])
                {

                    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets

                    g2.update();

                    /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                    grman::mettre_a_jour();
                    clique_bouton(g2, 2, "graphe2.txt", "matrice2.txt", "matrice_adj2.txt", false);
                }
                choix_graphe=menu_graphe(choix);
            }
            if(choix_graphe==3)
            {
                while(!(mouse_b&1 && mouse_x<85 && mouse_y<50) && !key[KEY_ESC])
                {

                    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets

                    g3.update();

                    /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                    grman::mettre_a_jour();
                    clique_bouton(g3, 3, "graphe3.txt", "matrice3.txt", "matrice_adj1.txt", false);
                }
                choix_graphe=menu_graphe(choix);
            }
        }
        if(choix==2)
        {
            choix_graphe=menu_graphe(choix_graphe);
            if(choix_graphe==1)
            {
                while(!(mouse_b&1 && mouse_x<85 && mouse_y<50) && !key[KEY_ESC])
                {
                    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
                    g1.update();

                    /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                    grman::mettre_a_jour();
                    clique_bouton(g1, choix_graphe, "graphe1.txt","matrice1.txt", "matrice_adj1.txt", true);
                }
            }
            if(choix_graphe==2)
            {
                while(!(mouse_b&1 && mouse_x<85 && mouse_y<50) && !key[KEY_ESC])
                {

                    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets

                    g2.update();

                    /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                    grman::mettre_a_jour();
                    clique_bouton(g2, 2, "graphe2.txt", "matrice2.txt", "matrice_adj2.txt", true);
                }
                choix_graphe=menu_graphe(choix);
            }
            if(choix_graphe==3)
            {
                while(!(mouse_b&1 && mouse_x<85 && mouse_y<50) && !key[KEY_ESC])
                {

                    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets

                    g3.update();

                    /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
                    grman::mettre_a_jour();
                    clique_bouton(g3, 3, "graphe3.txt", "matrice3.txt", "matrice_adj1.txt", true);
                }
                choix_graphe=menu_graphe(choix);
            }

        }
        if(choix==3)
        {
            Graph nouveau;
            nouveau.make_graph();
            while(!(mouse_b&1 && mouse_x<85 && mouse_y<50) && !key[KEY_ESC])
            {
                nouveau.update();
                grman::mettre_a_jour();
            }
        }
    }
    grman::fermer_allegro();        //on ferme allegro (fen�tre etc)
    return 0;
}
END_OF_MAIN();

/*  k_connexite: supprimer une arete => connexe?
    oui-> on rajoute l'arete, et on en supprime une autre
*/
