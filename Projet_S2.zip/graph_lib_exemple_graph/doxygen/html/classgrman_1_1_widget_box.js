var classgrman_1_1_widget_box =
[
    [ "captures_focus", "classgrman_1_1_widget_box.html#a2f9311b8df4e9add38fd595e0eaf2ec9", null ],
    [ "interact_focus", "classgrman_1_1_widget_box.html#a5de9d1bfbe85e470cdcc6ebb00f36b26", null ],
    [ "set_moveable", "classgrman_1_1_widget_box.html#a96f1aa069e1271d48e10ca91a6928ee9", null ],
    [ "m_contained", "classgrman_1_1_widget_box.html#ae8758f26d89a067827321bbd0bfb43fc", null ],
    [ "m_moveable", "classgrman_1_1_widget_box.html#a5db31005a4eaa084416ff9d1a2fd738d", null ],
    [ "m_pos_start_move", "classgrman_1_1_widget_box.html#aed748b443a9737dc7cdef6022ae53950", null ]
];