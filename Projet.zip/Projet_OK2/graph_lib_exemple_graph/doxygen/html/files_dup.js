var files_dup =
[
    [ "coords.h", "coords_8h_source.html", null ],
    [ "graph.h", "graph_8h_source.html", null ],
    [ "grman.h", "grman_8h_source.html", null ],
    [ "grman_couleurs.h", "grman__couleurs_8h_source.html", null ],
    [ "widget.h", "widget_8h_source.html", null ]
];