var searchData=
[
  ['set_5fbg_5fcolor',['set_bg_color',['../classgrman_1_1_widget.html#ae8f8fc19b6b0981895c38fdf7df4e4bb',1,'grman::Widget']]],
  ['set_5fno_5fgravity',['set_no_gravity',['../classgrman_1_1_widget.html#a61c632d3a7b2dee577e7a0be63fb16ff',1,'grman::Widget']]]
];
