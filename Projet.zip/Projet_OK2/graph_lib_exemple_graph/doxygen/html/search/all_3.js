var searchData=
[
  ['draw',['draw',['../classgrman_1_1_widget_text.html#af73e6a5dced3bd5ace8a99e0dd6c0e62',1,'grman::WidgetText::draw()'],['../classgrman_1_1_widget_edge.html#adbaeb94bef0a5334fd3ddc0fe30343c5',1,'grman::WidgetEdge::draw()']]]
];
