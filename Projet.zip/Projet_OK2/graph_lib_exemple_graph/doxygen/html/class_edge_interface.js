var class_edge_interface =
[
    [ "EdgeInterface", "class_edge_interface.html#a996267d30334b0cb47a3160a0e346282", null ],
    [ "Edge", "class_edge_interface.html#ad2c8ba04c9d9989ccbf3c5aba267a3d7", null ],
    [ "Graph", "class_edge_interface.html#afab89afd724f1b07b1aaad6bdc61c47a", null ]
];